<?php
require_once __DIR__ . '/../config.php';
$flashMessages = get_flash();
$title = $pageTitle ?? APP_NAME;
$assetBase = BASE_URL === '/' ? '' : BASE_URL;
$bodyClasses = trim('min-h-screen bg-slate-50 font-sans text-slate-800 antialiased ' . ($bodyClass ?? ''));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo htmlspecialchars($title); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: {
                            red: '#B22222',
                            redDark: '#8B1A1A',
                            gray: '#2F2F2F'
                        }
                    },
                    fontFamily: {
                        sans: ['"Inter"', '"Segoe UI"', 'system-ui', 'sans-serif']
                    },
                    boxShadow: {
                        glow: '0 25px 50px -12px rgba(178, 34, 34, 0.35)'
                    }
                }
            }
        }
    </script>
</head>
<body class="<?php echo htmlspecialchars($bodyClasses); ?>">
