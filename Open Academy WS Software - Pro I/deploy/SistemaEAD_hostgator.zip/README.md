# Training - PHP + MySQL + Tailwind

Este projeto implementa um sistema EAD com controle de usuarios (admin, gestor, aluno), cursos, avaliacao com 12 questoes e emissao de certificados. O front-end utiliza Tailwind CSS via CDN, explorando uma paleta moderna em vermelho e cinza.

## Estrutura

- `config.php`: configuracao de conexao com o banco MySQL e helpers globais.
- `includes/`: trechos reutilizaveis (cabecalho, navbar, autenticacao, alertas).
- `public/`: paginas acessiveis via navegador (login, dashboard, gestao, avaliacao, certificado).
- `database/schema.sql`: referencia do modelo relacional utilizado no banco.

## Requisitos

1. PHP 8+ com extensao `mysqli` habilitada
2. Servidor web (Apache/Nginx ou `php -S`) apontando para `public/`
3. MySQL local com o banco `sistemaead`

## Conexao com o banco local

Os dados de acesso estao configurados em `config.php`:

- Host: `127.0.0.1`
- Porta: `3306`
- Banco: `sistemaead`
- Usuario: `root`
- Senha: `#Jesussalva1980`

## Fluxo de uso

- **Admin**: gerencia usuarios e cursos.
- **Gestor**: gerencia cursos, matriculas e questoes.
- **Aluno**: acessa cursos, realiza avaliacao (12 questoes, nota minima 7.0) e gera certificado apos aprovacao.

## Credenciais iniciais

As credenciais ja estao cadastradas no banco e podem ser utilizadas para testes:

- Admin: `admin@ead.test` / `Senha@123`
- Gestor: `gestor@ead.test` / `Senha@123`
- Aluno: `aluno@ead.test` / `Senha@123`

## Acesso rapido\n\n1. Inicie o servidor local: php -S localhost:8000 -t public\n2. Abra [http://localhost:8000](http://localhost:8000) no navegador para acessar o login.\n\n
