    <script>
        document.querySelectorAll('[data-confirm]').forEach((el) => {
            el.addEventListener('click', (event) => {
                const message = el.getAttribute('data-confirm') || 'Confirmar a a��o?';
                if (!confirm(message)) {
                    event.preventDefault();
                }
            });
        });
    </script>
</body>
</html>
