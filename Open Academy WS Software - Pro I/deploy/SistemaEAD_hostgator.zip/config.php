﻿<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

define('APP_NAME', 'Training');
$scriptDir = dirname($_SERVER['SCRIPT_NAME']);
$scriptDir = str_replace('\\', '/', $scriptDir);
$scriptDir = preg_replace('#/+#', '/', $scriptDir);
$scriptDir = rtrim($scriptDir, '/');
define('BASE_URL', $scriptDir === '' ? '/' : $scriptDir);
define('PASSING_GRADE', 7.0);
define('QUESTION_COUNT', 12);
define('MODULE_QUESTION_COUNT', 2);

define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', '#Jesussalva1980');
define('DB_NAME', 'sistemaead');
define('DB_PORT', 3306);

function get_db(): mysqli
{
    static $connection;

    if ($connection instanceof mysqli) {
        return $connection;
    }

    $connection = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
    $connection->set_charset('utf8mb4');

    ensure_module_tables($connection);
    ensure_default_admin($connection);

    return $connection;
}

function redirect(string $path): void
{
    header('Location: ' . $path);
    exit;
}

function flash(string $message, string $type = 'info'): void
{
    $_SESSION['flash'][] = [
        'message' => $message,
        'type' => $type,
    ];
}

function get_flash(): array
{
    $messages = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $messages;
}
function resolve_video_embed(?string $url): ?array
{
    if ($url === null) {
        return null;
    }

    $url = trim($url);
    if ($url === '') {
        return null;
    }

    $streamable = ['mp4', 'webm', 'ogg', 'ogv', 'm4v'];

    if (!is_external_url($url)) {
        $normalized = $url;
        if ($normalized === '' || $normalized[0] !== '/') {
            $normalized = asset_url($normalized);
        }

        $path = parse_url($normalized, PHP_URL_PATH) ?? $normalized;
        $extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        if ($extension !== '' && in_array($extension, $streamable, true)) {
            return [
                'type' => 'video',
                'src' => $normalized
            ];
        }

        return null;
    }

    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        return null;
    }

    $parsed = parse_url($url);
    if ($parsed === false || !isset($parsed['host'])) {
        return null;
    }

    $host = strtolower($parsed['host']);
    $path = $parsed['path'] ?? '';

    if (str_contains($host, 'youtube.com') || str_contains($host, 'youtu.be')) {
        $videoId = '';

        if (str_contains($host, 'youtube.com')) {
            parse_str($parsed['query'] ?? '', $query);
            if (!empty($query['v'])) {
                $videoId = $query['v'];
            } elseif (!empty($path)) {
                $segments = array_values(array_filter(explode('/', $path)));
                if (!empty($segments)) {
                    $videoId = end($segments);
                }
            }
        }

        if ($videoId === '' && str_contains($host, 'youtu.be')) {
            $videoId = ltrim($path, '/');
        }

        if ($videoId !== '') {
            return [
                'type' => 'iframe',
                'src' => 'https://www.youtube.com/embed/' . urlencode($videoId),
                'allow' => 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share'
            ];
        }
    }

    if (str_contains($host, 'vimeo.com')) {
        $segments = array_values(array_filter(explode('/', $path)));
        if (!empty($segments)) {
            $videoId = end($segments);
            if (ctype_digit($videoId)) {
                return [
                    'type' => 'iframe',
                    'src' => 'https://player.vimeo.com/video/' . $videoId,
                    'allow' => 'autoplay; fullscreen; picture-in-picture'
                ];
            }
        }
    }

    $extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    if ($extension !== '' && in_array($extension, $streamable, true)) {
        return [
            'type' => 'video',
            'src' => $url
        ];
    }

    return null;
}

function render_video_player(?string $url): ?string
{
    $embed = resolve_video_embed($url);
    if ($embed === null) {
        return null;
    }

    $src = htmlspecialchars($embed['src'], ENT_QUOTES, 'UTF-8');
    if ($embed['type'] === 'iframe') {
        $allow = htmlspecialchars($embed['allow'] ?? 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture', ENT_QUOTES, 'UTF-8');
        return '<iframe src="' . $src . '" allow="' . $allow . '" allowfullscreen loading="lazy" title="Video do curso" style="width:100%;height:100%;border:0;"></iframe>';
    }

    if ($embed['type'] === 'video') {
        return '<video src="' . $src . '" controls class="w-full h-full" preload="metadata"></video>';
    }

    return null;
}
function is_external_url(?string $value): bool
{
    if ($value === null || $value === '') {
        return false;
    }

    return (bool) preg_match('#^https?://#i', $value);
}

function asset_url(?string $path): string
{
    if ($path === null || $path === '') {
        return '';
    }

    if (is_external_url($path)) {
        return $path;
    }

    $prefix = BASE_URL === '/' ? '' : BASE_URL;

    return $prefix . '/' . ltrim($path, '/');
}

function store_uploaded_signature(array $file): array
{
    $error = $file['error'] ?? UPLOAD_ERR_NO_FILE;
    if ($error !== UPLOAD_ERR_OK) {
        $messages = [
            UPLOAD_ERR_INI_SIZE => 'Arquivo de assinatura excede o tamanho maximo permitido.',
            UPLOAD_ERR_FORM_SIZE => 'Arquivo de assinatura excede o tamanho maximo permitido.',
            UPLOAD_ERR_PARTIAL => 'Upload da assinatura foi concluido parcialmente. Tente novamente.',
            UPLOAD_ERR_NO_FILE => 'Nenhum arquivo de assinatura enviado.',
        ];

        return [
            'success' => false,
            'message' => $messages[$error] ?? 'Falha ao enviar o arquivo da assinatura.',
        ];
    }

    $tmpName = $file['tmp_name'] ?? '';
    if ($tmpName === '' || !is_uploaded_file($tmpName)) {
        return [
            'success' => false,
            'message' => 'Upload de assinatura invalido. Tente novamente.',
        ];
    }

    $maxSize = 2 * 1024 * 1024; // 2 MB
    $size = (int) ($file['size'] ?? 0);
    if ($size <= 0 || $size > $maxSize) {
        return [
            'success' => false,
            'message' => 'A assinatura deve ter ate 2 MB no formato PNG.',
        ];
    }

    $imageInfo = @getimagesize($tmpName);
    if ($imageInfo === false || ($imageInfo[2] ?? null) !== IMAGETYPE_PNG) {
        return [
            'success' => false,
            'message' => 'Envie uma imagem PNG valida para a assinatura.',
        ];
    }

    $uploadDir = __DIR__ . '/public/uploads/signatures';
    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) {
        return [
            'success' => false,
            'message' => 'Nao foi possivel preparar a pasta para a assinatura.',
        ];
    }

    $original = pathinfo($file['name'] ?? 'assinatura', PATHINFO_FILENAME);
    $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $original));
    $slug = trim($slug, '-');
    if ($slug === '') {
        $slug = 'assinatura';
    }

    try {
        $filename = $slug . '-' . bin2hex(random_bytes(6)) . '.png';
    } catch (Throwable $exception) {
        $filename = $slug . '-' . uniqid('', true) . '.png';
    }

    $destination = $uploadDir . '/' . $filename;
    if (!move_uploaded_file($tmpName, $destination)) {
        return [
            'success' => false,
            'message' => 'Nao foi possivel salvar a assinatura enviada.',
        ];
    }

    return [
        'success' => true,
        'path' => 'uploads/signatures/' . $filename,
    ];
}

function store_uploaded_video(array $file): array
{
    $error = $file['error'] ?? UPLOAD_ERR_NO_FILE;
    if ($error !== UPLOAD_ERR_OK) {
        $messages = [
            UPLOAD_ERR_INI_SIZE => 'Arquivo de video excede o tamanho maximo permitido.',
            UPLOAD_ERR_FORM_SIZE => 'Arquivo de video excede o tamanho maximo permitido.',
            UPLOAD_ERR_PARTIAL => 'Upload do video foi concluido parcialmente. Tente novamente.',
            UPLOAD_ERR_NO_FILE => 'Nenhum arquivo de video enviado.',
        ];

        return [
            'success' => false,
            'message' => $messages[$error] ?? 'Falha ao enviar o arquivo de video.',
        ];
    }

    $tmpName = $file['tmp_name'] ?? '';
    if ($tmpName === '' || !is_uploaded_file($tmpName)) {
        return [
            'success' => false,
            'message' => 'Upload de video invalido. Tente novamente.',
        ];
    }

    $maxSize = 200 * 1024 * 1024; // 200 MB
    $size = (int) ($file['size'] ?? 0);
    if ($size <= 0 || $size > $maxSize) {
        return [
            'success' => false,
            'message' => 'O video deve ter ate 200 MB nos formatos MP4, WEBM ou OGG.',
        ];
    }

    $allowedExtensions = ['mp4', 'webm', 'ogg', 'ogv', 'm4v'];
    $allowedMime = ['video/mp4', 'video/webm', 'video/ogg', 'video/ogv', 'video/x-m4v', 'application/octet-stream'];

    $extension = strtolower(pathinfo($file['name'] ?? '', PATHINFO_EXTENSION));
    if (!in_array($extension, $allowedExtensions, true)) {
        return [
            'success' => false,
            'message' => 'Formato de video invalido. Utilize MP4, WEBM ou OGG.',
        ];
    }

    $mime = null;
    if (class_exists('finfo')) {
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $detected = $finfo->file($tmpName);
        if ($detected !== false) {
            $mime = $detected;
        }
    }

    if ($mime !== null && !in_array($mime, $allowedMime, true)) {
        return [
            'success' => false,
            'message' => 'Formato de video invalido. Utilize MP4, WEBM ou OGG.',
        ];
    }

    $uploadDir = __DIR__ . '/public/uploads/videos';
    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) {
        return [
            'success' => false,
            'message' => 'Nao foi possivel preparar a pasta para o video.',
        ];
    }

    $original = pathinfo($file['name'] ?? 'video', PATHINFO_FILENAME);
    $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $original));
    $slug = trim($slug, '-');
    if ($slug === '') {
        $slug = 'video';
    }

    try {
        $filename = $slug . '-' . bin2hex(random_bytes(8)) . '.' . $extension;
    } catch (Throwable $exception) {
        $filename = $slug . '-' . uniqid('', true) . '.' . $extension;
    }

    $destination = $uploadDir . '/' . $filename;
    if (!move_uploaded_file($tmpName, $destination)) {
        return [
            'success' => false,
            'message' => 'Nao foi possivel salvar o video enviado.',
        ];
    }

    return [
        'success' => true,
        'path' => 'uploads/videos/' . $filename,
    ];
}

function get_signature_settings(): array
{
    $defaults = [
        'name' => '',
        'title' => '',
        'image_path' => null,
    ];

    $path = __DIR__ . '/storage/signature_settings.json';
    if (!is_file($path)) {
        return $defaults;
    }

    $contents = file_get_contents($path);
    if ($contents === false) {
        return $defaults;
    }

    $decoded = json_decode($contents, true);
    if (!is_array($decoded)) {
        return $defaults;
    }

    return [
        'name' => trim((string) ($decoded['name'] ?? '')),
        'title' => trim((string) ($decoded['title'] ?? '')),
        'image_path' => ($decoded['image_path'] ?? null) !== '' ? (string) $decoded['image_path'] : null,
    ];
}

function save_signature_settings(array $settings): bool
{
    $payload = [
        'name' => trim((string) ($settings['name'] ?? '')),
        'title' => trim((string) ($settings['title'] ?? '')),
        'image_path' => $settings['image_path'] ?? null,
    ];

    $path = __DIR__ . '/storage/signature_settings.json';
    $directory = dirname($path);
    if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
        return false;
    }

    $json = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        return false;
    }

    return file_put_contents($path, $json, LOCK_EX) !== false;
}

function store_uploaded_pdf(array $file): array
{
    $error = $file['error'] ?? UPLOAD_ERR_NO_FILE;
    if ($error !== UPLOAD_ERR_OK) {
        $messages = [
            UPLOAD_ERR_INI_SIZE => 'Arquivo PDF excede o tamanho maximo permitido.',
            UPLOAD_ERR_FORM_SIZE => 'Arquivo PDF excede o tamanho maximo permitido.',
            UPLOAD_ERR_PARTIAL => 'Upload do PDF foi concluido parcialmente. Tente novamente.',
            UPLOAD_ERR_NO_FILE => 'Nenhum arquivo PDF enviado.',
        ];

        return [
            'success' => false,
            'message' => $messages[$error] ?? 'Falha ao enviar o arquivo PDF.',
        ];
    }

    $tmpName = $file['tmp_name'] ?? '';
    if ($tmpName === '' || !is_uploaded_file($tmpName)) {
        return [
            'success' => false,
            'message' => 'Upload de PDF invalido. Tente novamente.',
        ];
    }

    $maxSize = 10 * 1024 * 1024; // 10 MB
    $size = (int) ($file['size'] ?? 0);
    if ($size <= 0 || $size > $maxSize) {
        return [
            'success' => false,
            'message' => 'O PDF deve ter ate 10 MB.',
        ];
    }

    $mime = 'application/pdf';
    if (class_exists('finfo')) {
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $detected = $finfo->file($tmpName);
        if ($detected !== false) {
            $mime = $detected;
        }
    }

    $allowedMime = ['application/pdf', 'application/x-pdf', 'application/octet-stream'];
    $extension = strtolower(pathinfo($file['name'] ?? '', PATHINFO_EXTENSION));
    if ($extension !== 'pdf' || !in_array($mime, $allowedMime, true)) {
        return [
            'success' => false,
            'message' => 'Envie apenas arquivos no formato PDF.',
        ];
    }

    $uploadDir = __DIR__ . '/public/uploads/pdfs';
    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) {
        return [
            'success' => false,
            'message' => 'Nao foi possivel preparar a pasta para o PDF.',
        ];
    }

    $original = pathinfo($file['name'] ?? '', PATHINFO_FILENAME);
    $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $original));
    $slug = trim($slug, '-');
    if ($slug === '') {
        $slug = 'material';
    }

    try {
        $filename = $slug . '-' . bin2hex(random_bytes(8)) . '.pdf';
    } catch (Throwable $exception) {
        $filename = $slug . '-' . uniqid('', true) . '.pdf';
    }

    $destination = $uploadDir . '/' . $filename;
    if (!move_uploaded_file($tmpName, $destination)) {
        return [
            'success' => false,
            'message' => 'Nao foi possivel salvar o PDF enviado.',
        ];
    }

    return [
        'success' => true,
        'path' => 'uploads/pdfs/' . $filename,
    ];
}

function delete_uploaded_file(?string $path): void
{
    if ($path === null || $path === '' || is_external_url($path)) {
        return;
    }

    if (str_contains($path, '..')) {
        return;
    }

    $absolute = __DIR__ . '/public/' . ltrim($path, '/');
    if (is_file($absolute)) {
        @unlink($absolute);
    }
}



function ensure_module_tables(mysqli $db): void
{
    static $initialized = false;

    if ($initialized) {
        return;
    }

    if (($result = $db->query("SHOW COLUMNS FROM courses LIKE 'deadline'")) instanceof mysqli_result) {
        if ($result->num_rows === 0) {
            $db->query("ALTER TABLE courses ADD COLUMN deadline DATE DEFAULT NULL AFTER workload");
        }
        $result->free();
    }

    if (($result = $db->query("SHOW COLUMNS FROM courses LIKE 'certificate_validity_months'")) instanceof mysqli_result) {
        if ($result->num_rows === 0) {
            $db->query("ALTER TABLE courses ADD COLUMN certificate_validity_months INT UNSIGNED DEFAULT NULL AFTER deadline");
        }
        $result->free();
    }

    if (($result = $db->query("SHOW COLUMNS FROM assessment_results LIKE 'attempts'")) instanceof mysqli_result) {
        if ($result->num_rows === 0) {
            $db->query("ALTER TABLE assessment_results ADD COLUMN attempts INT UNSIGNED NOT NULL DEFAULT 0 AFTER approved");
        }
        $result->free();
    }

    if (($result = $db->query("SHOW COLUMNS FROM course_modules LIKE 'video_url'")) instanceof mysqli_result) {
        if ($result->num_rows === 0) {
            $db->query("ALTER TABLE course_modules ADD COLUMN video_url VARCHAR(255) DEFAULT NULL AFTER description");
        }
        $result->free();
    }

    if (($result = $db->query("SHOW COLUMNS FROM course_modules LIKE 'pdf_url'")) instanceof mysqli_result) {
        if ($result->num_rows === 0) {
            $db->query("ALTER TABLE course_modules ADD COLUMN pdf_url VARCHAR(255) DEFAULT NULL AFTER video_url");
        }
        $result->free();
    }

    $queries = [
        'CREATE TABLE IF NOT EXISTS course_modules (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            course_id INT UNSIGNED NOT NULL,
            title VARCHAR(160) NOT NULL,
            description TEXT,
            video_url VARCHAR(255) DEFAULT NULL,
            pdf_url VARCHAR(255) DEFAULT NULL,
            position INT UNSIGNED NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_modules_course (course_id),
            KEY idx_modules_order (course_id, position),
            CONSTRAINT fk_modules_course FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
        'CREATE TABLE IF NOT EXISTS module_questions (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            module_id INT UNSIGNED NOT NULL,
            prompt TEXT NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_module_questions_module (module_id),
            CONSTRAINT fk_module_questions_module FOREIGN KEY (module_id) REFERENCES course_modules (id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
        'CREATE TABLE IF NOT EXISTS module_question_options (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            question_id INT UNSIGNED NOT NULL,
            option_text TEXT NOT NULL,
            is_correct TINYINT(1) NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            KEY idx_module_options_question (question_id),
            CONSTRAINT fk_module_options_question FOREIGN KEY (question_id) REFERENCES module_questions (id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
        'CREATE TABLE IF NOT EXISTS module_topics (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            module_id INT UNSIGNED NOT NULL,
            title VARCHAR(160) NOT NULL,
            description TEXT,
            video_url VARCHAR(255) DEFAULT NULL,
            pdf_url VARCHAR(255) DEFAULT NULL,
            position INT UNSIGNED NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_topics_module (module_id),
            KEY idx_topics_order (module_id, position),
            CONSTRAINT fk_topics_module FOREIGN KEY (module_id) REFERENCES course_modules (id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
        'CREATE TABLE IF NOT EXISTS module_topic_progress (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            module_topic_id INT UNSIGNED NOT NULL,
            user_id INT UNSIGNED NOT NULL,
            completed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_topic_user (module_topic_id, user_id),
            KEY idx_progress_user (user_id),
            CONSTRAINT fk_progress_topic FOREIGN KEY (module_topic_id) REFERENCES module_topics (id) ON DELETE CASCADE,
            CONSTRAINT fk_progress_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
        'CREATE TABLE IF NOT EXISTS module_results (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            module_id INT UNSIGNED NOT NULL,
            user_id INT UNSIGNED NOT NULL,
            score DECIMAL(4,1) NOT NULL,
            approved TINYINT(1) NOT NULL DEFAULT 0,
            attempts INT UNSIGNED NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_module_user (module_id, user_id),
            KEY idx_module_results_user (user_id),
            CONSTRAINT fk_module_results_module FOREIGN KEY (module_id) REFERENCES course_modules (id) ON DELETE CASCADE,
            CONSTRAINT fk_module_results_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
        'CREATE TABLE IF NOT EXISTS module_answers (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            result_id INT UNSIGNED NOT NULL,
            question_id INT UNSIGNED NOT NULL,
            option_id INT UNSIGNED NOT NULL,
            is_correct TINYINT(1) NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_module_answers_result (result_id),
            KEY idx_module_answers_question (question_id),
            CONSTRAINT fk_module_answers_result FOREIGN KEY (result_id) REFERENCES module_results (id) ON DELETE CASCADE,
            CONSTRAINT fk_module_answers_question FOREIGN KEY (question_id) REFERENCES module_questions (id) ON DELETE CASCADE,
            CONSTRAINT fk_module_answers_option FOREIGN KEY (option_id) REFERENCES module_question_options (id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    ];

    foreach ($queries as $sql) {
        $db->query($sql);
    }

    $initialized = true;
}


function ensure_default_admin(mysqli $db): void
{
    static $checked = false;

    if ($checked) {
        return;
    }

    $email = 'admin@training.com';
    $stmt = $db->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
    if ($stmt) {
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $exists = $stmt->get_result()->fetch_assoc();
        if (!$exists) {
            $name = 'Administrador';
            $hash = password_hash('@admin123', PASSWORD_DEFAULT);
            $role = 'admin';
            $stmtInsert = $db->prepare('INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)');
            if ($stmtInsert) {
                $stmtInsert->bind_param('ssss', $name, $email, $hash, $role);
                $stmtInsert->execute();
                $stmtInsert->close();
            }
        }
        $stmt->close();
    }

    $checked = true;
}


