<?php
require_once __DIR__ . '/../includes/auth.php';

require_roles(['admin', 'gestor']);
require_once __DIR__ . '/../includes/enrollments.php';

$userId = (int) ($_GET['user_id'] ?? 0);
if ($userId <= 0) {
    flash('Usuario nao informado.', 'warning');
    redirect('users.php');
}

$db = get_db();

$stmtUser = $db->prepare('SELECT id, name, email, role, created_at FROM users WHERE id = ? LIMIT 1');
$stmtUser->bind_param('i', $userId);
$stmtUser->execute();
$userRow = $stmtUser->get_result()->fetch_assoc();

if (!$userRow) {
    flash('Usuario nao encontrado.', 'warning');
    redirect('users.php');
}

$viewerIsGestor = has_role('gestor');
if ($viewerIsGestor && $userRow['role'] !== 'aluno') {
    flash('Gestores podem alterar apenas perfis de alunos.', 'warning');
    redirect('users.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update') {
        $name = trim($_POST['name'] ?? '');
        $email = strtolower(trim($_POST['email'] ?? ''));
        $role = $_POST['role'] ?? '';
        if ($viewerIsGestor) {
            $role = 'aluno';
        }
        $password = $_POST['password'] ?? '';

        if ($name === '' || $email === '' || $role === '') {
            flash('Preencha nome, email e perfil.', 'warning');
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash('Informe um email valido.', 'warning');
        } elseif (!in_array($role, ['admin', 'gestor', 'aluno'], true)) {
            flash('Perfil de acesso invalido.', 'warning');
        } else {
            // Verifica email duplicado em outro usuario
            $stmtDup = $db->prepare('SELECT id FROM users WHERE email = ? AND id <> ? LIMIT 1');
            $stmtDup->bind_param('si', $email, $userId);
            $stmtDup->execute();
            if ($stmtDup->get_result()->fetch_assoc()) {
                flash('Este email ja esta em uso por outro usuario.', 'danger');
                redirect('user_detail.php?user_id=' . $userId);
            }

            if ($password !== '') {
                $passwordHash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $db->prepare('UPDATE users SET name = ?, email = ?, role = ?, password_hash = ? WHERE id = ?');
                $stmt->bind_param('ssssi', $name, $email, $role, $passwordHash, $userId);
            } else {
                $stmt = $db->prepare('UPDATE users SET name = ?, email = ?, role = ? WHERE id = ?');
                $stmt->bind_param('sssi', $name, $email, $role, $userId);
            }

            if ($stmt->execute()) {
                // Se o usuario editado for o atual, atualiza a sessao
                $current = current_user();
                if ($current && (int) $current['id'] === $userId) {
                    $_SESSION['user'] = [
                        'id' => $userId,
                        'name' => $name,
                        'email' => $email,
                        'role' => $role,
                    ];
                }
                flash('Dados do usuario atualizados.', 'success');
            } else {
                flash('Nao foi possivel atualizar o usuario.', 'danger');
            }
        }

        redirect('user_detail.php?user_id=' . $userId);
    }

    if ($action === 'enroll') {
        $courses = $_POST['courses'] ?? [];
        if ($userRow['role'] !== 'aluno') {
            flash('Apenas usuarios com perfil "aluno" podem ser matriculados em cursos.', 'warning');
        } elseif (empty($courses)) {
            flash('Selecione pelo menos um curso.', 'warning');
        } else {
            $added = enroll_user_in_courses($db, $userId, array_map('intval', $courses));
            if ($added > 0) {
                flash('Curso(s) atribuido(s) ao usuario.', 'success');
            } else {
                flash('Nenhuma atribuicao realizada (usuario ja matriculado ou perfil invalido).', 'info');
            }
        }
        redirect('user_detail.php?user_id=' . $userId);
    }

    if ($action === 'unenroll') {
        $courseId = (int) ($_POST['course_id'] ?? 0);
        if ($courseId > 0) {
            unenroll_user_from_course($db, $userId, $courseId);
            flash('Curso removido do usuario.', 'success');
        }
        redirect('user_detail.php?user_id=' . $userId);
    }
}

// Dados para exibicao
// Cursos matriculados e status
$stmtEnrolled = $db->prepare('SELECT c.id, c.title, c.workload, c.created_at, ar.score, ar.approved, ar.created_at AS assessment_at
    FROM enrollments e
    INNER JOIN courses c ON c.id = e.course_id
    LEFT JOIN assessment_results ar ON ar.course_id = e.course_id AND ar.user_id = e.user_id
    WHERE e.user_id = ?
    ORDER BY c.title');
$stmtEnrolled->bind_param('i', $userId);
$stmtEnrolled->execute();
$enrolledCourses = $stmtEnrolled->get_result()->fetch_all(MYSQLI_ASSOC);

// Cursos disponiveis (nao matriculados)
$stmtAvailable = $db->prepare('SELECT id, title FROM courses WHERE id NOT IN (
    SELECT course_id FROM enrollments WHERE user_id = ?
) ORDER BY title');
$stmtAvailable->bind_param('i', $userId);
$stmtAvailable->execute();
$availableCourses = $stmtAvailable->get_result()->fetch_all(MYSQLI_ASSOC);

$pageTitle = 'Usuario: ' . ($userRow['name'] ?? '');

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/navbar.php';
require_once __DIR__ . '/../includes/alerts.php';
?>
<div class="mx-auto max-w-7xl space-y-8 px-4 pb-12">
    <div class="rounded-3xl border border-slate-200 bg-white/90 p-8 shadow shadow-slate-900/10">
        <div class="flex flex-col gap-2 lg:flex-row lg:items-center lg:justify-between">
            <div>
                <h1 class="text-2xl font-bold tracking-tight text-brand-gray">Gerenciar usuario</h1>
                <p class="mt-1 text-sm text-slate-500">Atualize os dados do usuario e atribua cursos.</p>
            </div>
            <div class="text-right text-sm text-slate-500">
                <div><span class="font-semibold text-slate-700"><?php echo htmlspecialchars($userRow['name']); ?></span> • <?php echo htmlspecialchars($userRow['email']); ?></div>
                <div>Perfil: <span class="uppercase font-semibold"><?php echo htmlspecialchars($userRow['role']); ?></span></div>
            </div>
        </div>
    </div>

    <div class="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]">
        <div class="rounded-3xl border border-slate-200 bg-white p-6 shadow shadow-slate-900/10">
            <h2 class="text-lg font-semibold text-brand-gray">Editar usuario</h2>
            <p class="mt-1 text-sm text-slate-500">Altere as informacoes de acesso e o perfil.</p>
            <form method="post" class="mt-6 space-y-4" novalidate>
                <input type="hidden" name="action" value="update">
                <div>
                    <label for="name" class="mb-1 block text-sm font-semibold text-slate-600">Nome completo</label>
                    <input type="text" id="name" name="name" required value="<?php echo htmlspecialchars($userRow['name']); ?>" class="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 shadow-sm focus:border-brand-red focus:outline-none focus:ring-4 focus:ring-brand-red/20">
                </div>
                <div>
                    <label for="email" class="mb-1 block text-sm font-semibold text-slate-600">Email</label>
                    <input type="email" id="email" name="email" required value="<?php echo htmlspecialchars($userRow['email']); ?>" class="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 shadow-sm focus:border-brand-red focus:outline-none focus:ring-4 focus:ring-brand-red/20">
                </div>
                <div>
                    <label for="role" class="mb-1 block text-sm font-semibold text-slate-600">Perfil de acesso</label>
                    <?php if ($viewerIsGestor): ?>
                        <input type="hidden" name="role" value="aluno">
                        <span class="inline-flex items-center rounded-full border border-emerald-200 bg-emerald-50 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-emerald-700">Aluno</span>
                        <p class="mt-1 text-xs text-slate-500">Gestores nao podem alterar o perfil de acesso.</p>
                    <?php else: ?>
                        <select id="role" name="role" required class="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 shadow-sm focus:border-brand-red focus:outline-none focus:ring-4 focus:ring-brand-red/20">
                            <option value="admin" <?php echo $userRow['role']==='admin'?'selected':''; ?>>Administrador</option>
                            <option value="gestor" <?php echo $userRow['role']==='gestor'?'selected':''; ?>>Gestor</option>
                            <option value="aluno" <?php echo $userRow['role']==='aluno'?'selected':''; ?>>Aluno</option>
                        </select>
                    <?php endif; ?>
                </div>
                <div>
                    <label for="password" class="mb-1 block text-sm font-semibold text-slate-600">Nova senha (opcional)</label>
                    <input type="password" id="password" name="password" placeholder="Deixe em branco para manter" class="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 shadow-sm focus:border-brand-red focus:outline-none focus:ring-4 focus:ring-brand-red/20">
                </div>
                <div class="pt-2">
                    <button type="submit" class="inline-flex w-full items-center justify-center rounded-2xl bg-brand-red px-5 py-3 text-sm font-semibold text-white shadow-glow transition hover:bg-brand-redDark focus:outline-none focus:ring-4 focus:ring-brand-red/30">Salvar alteracoes</button>
                </div>
            </form>
        </div>

        <div class="space-y-6">
            <div class="rounded-3xl border border-slate-200 bg-white shadow shadow-slate-900/10">
                <div class="flex items-start justify-between gap-4 border-b border-slate-100 px-6 py-5">
                    <div>
                        <h2 class="text-lg font-semibold text-brand-gray">Cursos do usuario</h2>
                        <p class="text-sm text-slate-500"><?php echo count($enrolledCourses); ?> curso(s) atribuido(s).</p>
                    </div>
                </div>
                <div class="overflow-hidden">
                    <table class="min-w-full divide-y divide-slate-200 text-sm">
                        <thead class="bg-brand-gray text-left text-xs font-semibold uppercase tracking-[0.25em] text-white">
                            <tr>
                                <th class="px-6 py-3">Curso</th>
                                <th class="px-6 py-3">Carga</th>
                                <th class="px-6 py-3">Avaliacao</th>
                                <th class="px-6 py-3 text-right">Acoes</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 bg-white">
                            <?php foreach ($enrolledCourses as $course): ?>
                                <tr class="transition hover:bg-slate-50">
                                    <td class="px-6 py-4 font-semibold text-slate-700"><?php echo htmlspecialchars($course['title']); ?></td>
                                    <td class="px-6 py-4 text-slate-500"><?php echo (int) ($course['workload'] ?? 0); ?>h</td>
                                    <td class="px-6 py-4 text-slate-500">
                                        <?php if ($course['score'] !== null): ?>
                                            <span class="font-semibold text-brand-red"><?php echo number_format((float) $course['score'], 1); ?></span>
                                            <?php echo $course['approved'] ? '<span class="ml-2 inline-flex items-center rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-emerald-700">Aprovado</span>' : '<span class="ml-2 inline-flex items-center rounded-full bg-slate-200 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-slate-600">Reprovado</span>'; ?>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 text-right">
                                        <form method="post" class="inline">
                                            <input type="hidden" name="action" value="unenroll">
                                            <input type="hidden" name="course_id" value="<?php echo (int) $course['id']; ?>">
                                            <button type="submit" data-confirm="Remover este curso do usuario?" class="inline-flex items-center rounded-full border border-rose-300 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-rose-600 transition hover:bg-rose-500 hover:text-white">Remover</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (empty($enrolledCourses)): ?>
                                <tr>
                                    <td colspan="4" class="px-6 py-12 text-center text-sm text-slate-500">Nenhum curso atribuido a este usuario.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="rounded-3xl border border-slate-200 bg-white p-6 shadow shadow-slate-900/10">
                <h2 class="text-lg font-semibold text-brand-gray">Atribuir cursos</h2>
                <?php if ($userRow['role'] !== 'aluno'): ?>
                    <p class="mt-1 text-sm text-amber-700">Apenas usuarios com perfil "aluno" podem ser matriculados em cursos.</p>
                <?php endif; ?>
                <form method="post" class="mt-5 space-y-4" novalidate>
                    <input type="hidden" name="action" value="enroll">
                    <div>
                        <label for="courses" class="mb-1 block text-sm font-semibold text-slate-600">Selecione os cursos</label>
                        <select id="courses" name="courses[]" multiple size="6" class="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 shadow-sm focus:border-brand-red focus:outline-none focus:ring-4 focus:ring-brand-red/20" <?php echo $userRow['role']!=='aluno' ? 'disabled' : ''; ?>>
                            <?php foreach ($availableCourses as $course): ?>
                                <option value="<?php echo (int) $course['id']; ?>"><?php echo htmlspecialchars($course['title']); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <p class="mt-1 text-xs text-slate-500">Segure Ctrl (Windows) ou Cmd (macOS) para selecionar varios.</p>
                    </div>
                    <div>
                        <button type="submit" class="inline-flex items-center justify-center rounded-2xl bg-brand-red px-5 py-3 text-sm font-semibold text-white shadow-glow transition hover:bg-brand-redDark focus:outline-none focus:ring-4 focus:ring-brand-red/30" <?php echo ($userRow['role']!=='aluno' || empty($availableCourses)) ? 'disabled' : ''; ?>>
                            Atribuir curso(s)
                        </button>
                        <?php if (empty($availableCourses)): ?>
                            <p class="mt-2 text-xs text-slate-500">Nenhum curso disponivel para atribuir.</p>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
