﻿<?php
require_once __DIR__ . '/../includes/auth.php';

require_roles(['admin', 'gestor']);

$pageTitle = 'Cursos';
$db = get_db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $videoUrl = trim($_POST['video_url'] ?? '');
        $workload = (int) ($_POST['workload'] ?? 0);
        $deadlineRaw = trim($_POST['deadline'] ?? '');
        $deadlineValue = null;
        $validityRaw = trim($_POST['certificate_validity_months'] ?? '');
        $validityMonths = null;
        $pdfPath = null;
        $uploadedVideoPath = null;

        $pdfFile = $_FILES['pdf_file'] ?? null;
        if ($pdfFile && ($pdfFile['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            $upload = store_uploaded_pdf($pdfFile);
            if (!$upload['success']) {
                flash($upload['message'], 'warning');
                redirect('courses.php');
            }
            $pdfPath = $upload['path'];
        }

        $videoFile = $_FILES['video_file'] ?? null;
        if ($videoFile && ($videoFile['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            $videoUpload = store_uploaded_video($videoFile);
            if (!$videoUpload['success']) {
                if ($pdfPath !== null) {
                    delete_uploaded_file($pdfPath);
                }
                flash($videoUpload['message'], 'warning');
                redirect('courses.php');
            }
            $uploadedVideoPath = $videoUpload['path'];
        }

        if ($deadlineRaw !== '') {
            $deadlineDate = DateTime::createFromFormat('Y-m-d', $deadlineRaw);
            if ($deadlineDate === false) {
                if ($pdfPath !== null) {
                    delete_uploaded_file($pdfPath);
                }
                if ($uploadedVideoPath !== null) {
                    delete_uploaded_file($uploadedVideoPath);
                }
                flash('Informe uma data limite valida.', 'warning');
                redirect('courses.php');
            }
            $deadlineValue = $deadlineDate->format('Y-m-d');
        }

        if ($validityRaw !== '') {
            if (!ctype_digit($validityRaw)) {
                if ($pdfPath !== null) {
                    delete_uploaded_file($pdfPath);
                }
                if ($uploadedVideoPath !== null) {
                    delete_uploaded_file($uploadedVideoPath);
                }
                flash('Informe a validade do certificado em meses utilizando apenas numeros inteiros.', 'warning');
                redirect('courses.php');
            }

            $validityParsed = (int) $validityRaw;
            if ($validityParsed > 0) {
                $validityMonths = $validityParsed;
            }
        }

        if ($uploadedVideoPath === null && $videoUrl !== '' && !filter_var($videoUrl, FILTER_VALIDATE_URL)) {
            if ($pdfPath !== null) {
                delete_uploaded_file($pdfPath);
            }
            flash('Informe uma URL valida para o video ou envie um arquivo.', 'warning');
        } elseif (!$title || !$description || $workload <= 0) {
            if ($pdfPath !== null) {
                delete_uploaded_file($pdfPath);
            }
            if ($uploadedVideoPath !== null) {
                delete_uploaded_file($uploadedVideoPath);
            }
            flash('Preencha titulo, descricao e carga horaria.', 'warning');
        } else {
            $videoValue = $uploadedVideoPath !== null ? $uploadedVideoPath : ($videoUrl !== '' ? $videoUrl : null);

            $stmt = $db->prepare('INSERT INTO courses (title, description, video_url, pdf_url, workload, deadline, certificate_validity_months, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
            $creatorId = current_user()['id'];
            $stmt->bind_param('ssssisii', $title, $description, $videoValue, $pdfPath, $workload, $deadlineValue, $validityMonths, $creatorId);
            if ($stmt->execute()) {
                flash('Curso criado com sucesso.', 'success');
            } else {
                if ($pdfPath !== null) {
                    delete_uploaded_file($pdfPath);
                }
                if ($uploadedVideoPath !== null) {
                    delete_uploaded_file($uploadedVideoPath);
                }
                flash('Nao foi possivel criar o curso.', 'danger');
            }
        }
    }
    if ($action === 'delete') {
        $courseId = (int) ($_POST['course_id'] ?? 0);
        if ($courseId > 0) {
            $stmtMedia = $db->prepare('SELECT pdf_url, video_url FROM courses WHERE id = ? LIMIT 1');
            $stmtMedia->bind_param('i', $courseId);
            $stmtMedia->execute();
            $mediaRow = $stmtMedia->get_result()->fetch_assoc();
            $pdfPath = $mediaRow['pdf_url'] ?? null;
            $videoPath = $mediaRow['video_url'] ?? null;

            $stmt = $db->prepare('DELETE FROM courses WHERE id = ? LIMIT 1');
            $stmt->bind_param('i', $courseId);
            if ($stmt->execute()) {
                delete_uploaded_file($pdfPath ?? null);
                delete_uploaded_file($videoPath ?? null);
                flash('Curso removido.', 'success');
            } else {
                flash('Erro ao remover curso.', 'danger');
            }
        }
    }
    redirect('courses.php');
}

$sql = 'SELECT c.id, c.title, c.description, c.video_url, c.pdf_url, c.workload, c.created_at, u.name AS author
    FROM courses c
    LEFT JOIN users u ON u.id = c.created_by
    ORDER BY c.created_at DESC';
$result = $db->query($sql);
$courses = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/navbar.php';
require_once __DIR__ . '/../includes/alerts.php';
?>
<div class="mx-auto max-w-7xl space-y-8 px-4 pb-12">
    <div class="rounded-3xl border border-slate-200 bg-white/90 p-8 shadow shadow-slate-900/10">
        <h1 class="text-2xl font-bold tracking-tight text-brand-gray">Gestao de cursos</h1>
        <p class="mt-2 text-sm text-slate-500">Crie trilhas de conhecimento, inclua materiais de apoio (videos e PDFs) e acompanhe o engajamento dos alunos.</p>
    </div>

    <div class="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]">
        <div class="rounded-3xl border border-slate-200 bg-white p-6 shadow shadow-slate-900/10">
            <h2 class="text-lg font-semibold text-brand-gray">Novo curso</h2>
            <p class="mt-1 text-sm text-slate-500">Defina um titulo atrativo, descreva o conteudo e adicione recursos multimidia (opcional).</p>
            <form method="post" enctype="multipart/form-data" class="mt-6 space-y-4" novalidate>
                <input type="hidden" name="action" value="create">
                <div>
                    <label for="title" class="mb-1 block text-sm font-semibold text-slate-600">Titulo</label>
                    <input type="text" id="title" name="title" required placeholder="Nome do curso" class="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 shadow-sm focus:border-brand-red focus:outline-none focus:ring-4 focus:ring-brand-red/20">
                </div>
                <div>
                    <label for="description" class="mb-1 block text-sm font-semibold text-slate-600">Descricao</label>
                    <textarea id="description" name="description" rows="4" required placeholder="Descreva o conteudo" class="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 shadow-sm focus:border-brand-red focus:outline-none focus:ring-4 focus:ring-brand-red/20"></textarea>
                </div>
                <div>
                    <label for="video_url" class="mb-1 block text-sm font-semibold text-slate-600">Video (URL)</label>
                    <input type="url" id="video_url" name="video_url" placeholder="https://..." class="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 shadow-sm focus:border-brand-red focus:outline-none focus:ring-4 focus:ring-brand-red/20">
                    <p class="mt-1 text-xs text-slate-500">Cole o link do video hospedado (YouTube, Vimeo, etc.).</p>
                    <div class="mt-3 space-y-2">
                        <label for="video_file" class="block text-sm font-semibold text-slate-600">Ou envie um video (MP4, WEBM, OGG)</label>
                        <input type="file" id="video_file" name="video_file" accept="video/mp4,video/webm,video/ogg,video/ogv,video/x-m4v" class="block w-full rounded-2xl border border-dashed border-slate-300 bg-white px-4 py-3 text-sm text-slate-700 shadow-sm focus:border-brand-red focus:outline-none focus:ring-4 focus:ring-brand-red/20">
                        <p class="text-xs text-slate-500">Tamanho maximo 200 MB. O arquivo enviado substitui o link informado acima.</p>
                    </div>
                </div>
                <div>
                    <label for="pdf_file" class="mb-1 block text-sm font-semibold text-slate-600">Material PDF</label>
                    <input type="file" id="pdf_file" name="pdf_file" accept="application/pdf" class="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 shadow-sm focus:border-brand-red focus:outline-none focus:ring-4 focus:ring-brand-red/20">
                    <p class="mt-1 text-xs text-slate-500">Envie um arquivo PDF de ate 10 MB.</p>
                </div>
                <div>
                    <label for="workload" class="mb-1 block text-sm font-semibold text-slate-600">Carga horaria (h)</label>
                    <input type="number" min="1" id="workload" name="workload" required placeholder="Ex.: 40" class="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 shadow-sm focus:border-brand-red focus:outline-none focus:ring-4 focus:ring-brand-red/20">
                </div>
                <div>
                    <label for="certificate_validity_months" class="mb-1 block text-sm font-semibold text-slate-600">Validade do certificado (meses)</label>
                    <input type="number" min="0" id="certificate_validity_months" name="certificate_validity_months" placeholder="Deixe em branco para validade indeterminada" class="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 shadow-sm focus:border-brand-red focus:outline-none focus:ring-4 focus:ring-brand-red/20">
                    <p class="mt-1 text-xs text-slate-500">Informe em meses. Utilize 0 ou deixe em branco para certificados sem data de expiracao.</p>
                </div>
                <div class="pt-2">
                    <button type="submit" class="inline-flex w-full items-center justify-center rounded-2xl bg-brand-red px-5 py-3 text-sm font-semibold text-white shadow-glow transition hover:bg-brand-redDark focus:outline-none focus:ring-4 focus:ring-brand-red/30">
                        Publicar curso
                    </button>
                </div>
            </form>
        </div>
        <div class="rounded-3xl border border-slate-200 bg-white shadow shadow-slate-900/10">
            <div class="flex items-start justify-between gap-4 border-b border-slate-100 px-6 py-5">
                <div>
                    <h2 class="text-lg font-semibold text-brand-gray">Cursos publicados</h2>
                    <p class="text-sm text-slate-500"><?php echo count($courses); ?> curso(s) ativos na plataforma.</p>
                </div>
            </div>
            <div class="overflow-hidden">
                <table class="min-w-full divide-y divide-slate-200 text-sm">
                    <thead class="bg-brand-gray text-left text-xs font-semibold uppercase tracking-[0.25em] text-white">
                        <tr>
                            <th class="px-6 py-3">Titulo</th>
                            <th class="px-6 py-3">Recursos</th>
                            <th class="px-6 py-3">Carga</th>
                            <th class="px-6 py-3">Responsavel</th>
                            <th class="px-6 py-3">Criado em</th>
                            <th class="px-6 py-3 text-right">Acoes</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 bg-white">
                        <?php foreach ($courses as $course): ?>
                            <tr class="transition hover:bg-slate-50">
                                <td class="px-6 py-4 font-semibold text-slate-700"><?php echo htmlspecialchars($course['title']); ?></td>
                                <td class="px-6 py-4 text-slate-500">
                                    <div class="flex flex-wrap gap-2">
                                        <?php
                                            $rawVideoUrl = $course['video_url'] ?? '';
                                            $videoLink = null;
                                            if (!empty($rawVideoUrl)) {
                                                $videoLink = is_external_url($rawVideoUrl) ? $rawVideoUrl : asset_url($rawVideoUrl);
                                            }
                                        ?>
                                        <?php if ($videoLink): ?>
                                            <a href="<?php echo htmlspecialchars($videoLink); ?>" target="_blank" class="inline-flex w-full items-center justify-center rounded-full border border-brand-red/30 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-brand-red transition hover:bg-brand-red hover:text-white sm:w-auto">Video</a>
                                        <?php endif; ?>
                                        <?php if (!empty($course['pdf_url'])): ?>
                                            <a href="material.php?course_id=<?php echo (int) $course['id']; ?>" class="inline-flex w-full items-center justify-center rounded-full border border-brand-red/30 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-brand-red transition hover:bg-brand-red hover:text-white sm:w-auto">Ler PDF</a>
                                            <a href="<?php echo htmlspecialchars(asset_url($course['pdf_url'])); ?>" download class="inline-flex w-full items-center justify-center rounded-full border border-slate-300 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-slate-600 transition hover:bg-slate-700 hover:text-white sm:w-auto">Baixar PDF</a>
                                        <?php endif; ?>
                                        <?php if (!$videoLink && empty($course['pdf_url'])): ?>
                                            <span class="text-xs text-slate-400">Sem recursos</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td class="px-6 py-4 text-slate-500"><?php echo (int) $course['workload']; ?>h</td>
                                <td class="px-6 py-4 text-slate-500"><?php echo htmlspecialchars($course['author'] ?? ''); ?></td>
                                <td class="px-6 py-4 text-slate-500"><?php echo $course['created_at'] ? date('d/m/Y', strtotime($course['created_at'])) : '-'; ?></td>
                                <td class="px-6 py-4 text-right">
                                    <div class="flex flex-wrap gap-2 sm:justify-end">
                                        <a href="course_detail.php?course_id=<?php echo (int) $course['id']; ?>" class="inline-flex w-full items-center justify-center rounded-full border border-slate-300 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-slate-600 transition hover:bg-slate-700 hover:text-white sm:w-auto">Editar</a>
                                        <form method="post" class="flex w-full sm:w-auto">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="course_id" value="<?php echo (int) $course['id']; ?>">
                                            <button type="submit" data-confirm="Excluir o curso e seus dados associados?" class="inline-flex w-full items-center justify-center rounded-full border border-rose-300 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-rose-600 transition hover:bg-rose-500 hover:text-white sm:w-auto">
                                                Excluir
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($courses)): ?>
                            <tr>
                                <td colspan="6" class="px-6 py-12 text-center text-sm text-slate-500">Nenhum curso cadastrado ainda. Comece publicando sua primeira turma.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>















