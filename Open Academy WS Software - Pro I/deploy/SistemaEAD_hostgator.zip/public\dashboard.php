﻿<?php
require_once __DIR__ . '/../includes/auth.php';

require_login();

$pageTitle = 'Dashboard';
$db = get_db();
$user = current_user();

$totalUsers = 0;
$totalCourses = 0;
$totalApproved = 0;
$studentCourses = [];

if (has_role('admin')) {
    $totalUsers = (int) ($db->query("SELECT COUNT(*) AS total FROM users")?->fetch_assoc()['total'] ?? 0);
    $totalCourses = (int) ($db->query("SELECT COUNT(*) AS total FROM courses")?->fetch_assoc()['total'] ?? 0);
    $totalApproved = (int) ($db->query("SELECT COUNT(*) AS total FROM assessment_results WHERE approved = 1")?->fetch_assoc()['total'] ?? 0);
} elseif (has_role('gestor')) {
    $totalCourses = (int) ($db->query("SELECT COUNT(*) AS total FROM courses")?->fetch_assoc()['total'] ?? 0);
    $totalApproved = (int) ($db->query("SELECT COUNT(*) AS total FROM assessment_results WHERE approved = 1")?->fetch_assoc()['total'] ?? 0);
} else {
    $stmt = $db->prepare('SELECT c.id, c.title, c.description, c.video_url, c.pdf_url, ar.score, ar.approved
        FROM enrollments e
        INNER JOIN courses c ON c.id = e.course_id
        LEFT JOIN assessment_results ar ON ar.user_id = e.user_id AND ar.course_id = e.course_id
        WHERE e.user_id = ?
        ORDER BY c.title');
    $stmt->bind_param('i', $user['id']);
    $stmt->execute();
    $studentCourses = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

$stmtModules = $db->prepare('SELECT id, title, description, video_url, pdf_url, position FROM course_modules WHERE course_id = ? ORDER BY position, id');
$stmtModuleResult = $db->prepare('SELECT score, approved, updated_at FROM module_results WHERE module_id = ? AND user_id = ?');
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/navbar.php';
require_once __DIR__ . '/../includes/alerts.php';

$firstName = explode(' ', trim($user['name']))[0] ?? $user['name'];
?>
<div class="mx-auto max-w-7xl space-y-8 px-4 pb-12">
    <div class="rounded-3xl border border-slate-200 bg-white/90 p-8 shadow shadow-slate-900/10">
        <span class="inline-flex items-center gap-2 rounded-full bg-brand-red/10 px-4 py-1 text-xs font-semibold uppercase tracking-[0.3em] text-brand-red">Painel principal</span>
        <h1 class="mt-4 text-3xl font-bold tracking-tight text-brand-gray">Bem-vindo, <?php echo htmlspecialchars($firstName); ?>!</h1>
        <p class="mt-2 text-sm text-slate-500">Acompanhe o desempenho da plataforma, monitore cursos e agilize as avaliacoes dos estudantes.</p>
    </div>

    <?php if (has_role('admin') || has_role('gestor')): ?>
        <div class="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <?php if (has_role('admin')): ?>
                <div class="rounded-3xl bg-gradient-to-br from-brand-red to-brand-redDark p-6 text-white shadow-glow">
                    <span class="text-xs uppercase tracking-[0.4em] text-white/70">Usuarios ativos</span>
                    <p class="mt-3 text-4xl font-bold"><?php echo $totalUsers; ?></p>
                    <p class="text-sm text-white/80">Perfis cadastrados na plataforma</p>
                </div>
            <?php endif; ?>
            <div class="rounded-3xl bg-gradient-to-br from-brand-gray/95 to-brand-gray/80 p-6 text-white shadow-xl shadow-brand-gray/35">
                <span class="text-xs uppercase tracking-[0.4em] text-white/70">Cursos</span>
                <p class="mt-3 text-4xl font-bold"><?php echo $totalCourses; ?></p>
                <p class="text-sm text-white/80">Turmas publicadas</p>
            </div>
            <div class="rounded-3xl bg-gradient-to-br from-brand-red to-brand-redDark p-6 text-white shadow-glow">
                <span class="text-xs uppercase tracking-[0.4em] text-white/70">Certificados</span>
                <p class="mt-3 text-4xl font-bold"><?php echo $totalApproved; ?></p>
                <p class="text-sm text-white/80">Avaliacoes aprovadas</p>
            </div>
        </div>
    <?php else: ?>
        <div class="space-y-4">
            <div>
                <h2 class="text-lg font-semibold text-brand-gray">Cursos em andamento</h2>
                <p class="text-sm text-slate-500">Acesse suas aulas, realize avaliacoes e acompanhe o progresso das notas.</p>
            </div>
            <?php if (empty($studentCourses)): ?>
                <div class="rounded-3xl border border-slate-200 bg-white p-10 text-center text-sm text-slate-500 shadow shadow-slate-900/10">
                    Voce ainda nao possui cursos matriculados. Procure o gestor para iniciar sua jornada.
                </div>
            <?php else: ?>
                <div class="grid gap-4 md:grid-cols-2">
                    <?php foreach ($studentCourses as $course): ?>
                        <?php
                            $description = $course['description'] ?? '';
                            $preview = strlen($description) > 120 ? substr($description, 0, 120) . '...' : $description;

                            $moduleItems = [];
                            $hasModules = false;
                            $allModulesApproved = true;

                            if ($stmtModules) {
                                $stmtModules->bind_param('i', $course['id']);
                                $stmtModules->execute();
                                $moduleRows = $stmtModules->get_result()->fetch_all(MYSQLI_ASSOC);
                                if (!empty($moduleRows)) {
                                    $hasModules = true;
                                    foreach ($moduleRows as $moduleRow) {
                                        if ($stmtModuleResult) {
                                            $stmtModuleResult->bind_param('ii', $moduleRow['id'], $user['id']);
                                            $stmtModuleResult->execute();
                                            $moduleResultRow = $stmtModuleResult->get_result()->fetch_assoc();
                                        } else {
                                            $moduleResultRow = null;
                                        }
                                        if (!$moduleResultRow || (int) ($moduleResultRow['approved'] ?? 0) !== 1) {
                                            $allModulesApproved = false;
                                        }
                                        $moduleItems[] = [
                                            'data' => $moduleRow,
                                            'result' => $moduleResultRow,
                                        ];
                                    }
                                }
                            }
                        ?>
                        <div class="flex h-full flex-col justify-between rounded-3xl border border-slate-200 bg-white p-6 shadow shadow-slate-900/10">
                            <div>
                                <h3 class="text-lg font-semibold text-brand-gray"><?php echo htmlspecialchars($course['title']); ?></h3>
                                <p class="mt-2 text-sm text-slate-500"><?php echo htmlspecialchars($preview); ?></p>
                            </div>
                            <div class="mt-4 flex flex-col gap-3">
                                <div>
                                    <?php if ($course['score'] !== null): ?>
                                        <span class="inline-flex items-center rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-emerald-700">
                                            Nota: <?php echo number_format((float) $course['score'], 1); ?>
                                            <?php echo $course['approved'] ? ' - Aprovado' : ' - Nao aprovado'; ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-amber-700">Avaliacao pendente</span>
                                    <?php endif; ?>
                                </div>
                                <?php
                                    $rawVideoUrl = $course['video_url'] ?? '';
                                    $hasVideoUrl = $rawVideoUrl !== '';
                                    $videoLink = null;
                                    if ($hasVideoUrl) {
                                        $videoLink = is_external_url($rawVideoUrl) ? $rawVideoUrl : asset_url($rawVideoUrl);
                                    }
                                    $videoPlayer = $hasVideoUrl ? render_video_player($videoLink) : null;
                                    $pdfPath = $course['pdf_url'] ?? '';
                                    $hasPdfUrl = !empty($pdfPath);
                                    $pdfAssetUrl = $hasPdfUrl ? asset_url($pdfPath) : '';
                                    $hasPdfUrl = $hasPdfUrl && $pdfAssetUrl !== '';
                                ?>
                                <?php if ($videoPlayer || $hasVideoUrl || $hasPdfUrl): ?>
                                    <div class="flex flex-col gap-3">
                                        <?php if ($videoPlayer): ?>
                                            <div class="overflow-hidden rounded-2xl border border-slate-200 bg-black" style="aspect-ratio: 16 / 9;">
                                                <?php echo $videoPlayer; ?>
                                            </div>
                                        <?php endif; ?>
                                        <div class="flex flex-wrap gap-2">
                                            <?php if ($hasVideoUrl && $videoLink): ?>
                                                <a href="<?php echo htmlspecialchars($videoLink); ?>" target="_blank" class="inline-flex items-center rounded-full border border-brand-red/30 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-brand-red transition hover:bg-brand-red hover:text-white">
                                                    <?php echo $videoPlayer ? 'Abrir video em nova aba' : 'Video'; ?>
                                                </a>
                                            <?php endif; ?>
                                            <?php if ($hasPdfUrl): ?>
                                                <a href="material.php?course_id=<?php echo (int) $course['id']; ?>" class="inline-flex items-center rounded-full border border-brand-red/30 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-brand-red transition hover:bg-brand-red hover:text-white">Ler PDF</a>
                                                <a href="<?php echo htmlspecialchars($pdfAssetUrl); ?>" download class="inline-flex items-center rounded-full border border-slate-300 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-slate-600 transition hover:bg-slate-700 hover:text-white">Baixar PDF</a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <?php if (!empty($moduleItems)): ?>
                                    <div class="space-y-2">
                                        <h4 class="text-xs font-semibold uppercase tracking-wide text-slate-500">Modulos</h4>
                                        <?php foreach ($moduleItems as $item): ?>
                                            <?php
                                                $moduleData = $item['data'];
                                                $moduleResult = $item['result'] ?? null;
                                                $isApproved = ($moduleResult && (int) $moduleResult['approved'] === 1);
                                                $badgeClass = $isApproved ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-200 text-slate-600';
                                            ?>
                                            <div class="rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-600">
                                                <div class="flex flex-wrap items-center gap-2 sm:justify-between">
                                                    <div>
                                                        <p class="font-semibold text-brand-gray"><?php echo htmlspecialchars($moduleData['title']); ?></p>
                                                        <?php if ($moduleResult): ?>
                                                            <p class="text-[11px] text-slate-500">Nota <?php echo number_format((float) ($moduleResult['score'] ?? 0), 1); ?> Â· <?php echo $isApproved ? 'Aprovado' : 'Nao aprovado'; ?></p>
                                                        <?php else: ?>
                                                            <p class="text-[11px] text-slate-500">Questionario pendente</p>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="flex w-full flex-col items-stretch gap-1 sm:w-auto sm:items-end">
                                                        <span class="inline-flex items-center justify-center rounded-full px-2 py-1 text-[11px] font-semibold uppercase tracking-wide <?php echo $badgeClass; ?>"><?php echo $isApproved ? 'Concluido' : 'Pendente'; ?></span>
                                                        <a href="module.php?module_id=<?php echo (int) $moduleData['id']; ?>" class="inline-flex w-full items-center justify-center rounded-full border border-brand-red/30 px-2 py-1 text-[11px] font-semibold uppercase tracking-wide text-brand-red transition hover:bg-brand-red hover:text-white sm:w-auto"><?php echo $isApproved ? 'Revisar' : 'Iniciar'; ?></a>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                                <div class="flex flex-wrap gap-2">
                                    <?php if ($course['approved']): ?>
                                        <span class="inline-flex w-full items-center justify-center rounded-2xl border border-emerald-300 bg-emerald-50 px-4 py-2 text-sm font-semibold uppercase tracking-wide text-emerald-700">Avaliacao concluida</span>
                                    <?php elseif ($hasModules && !$allModulesApproved): ?>
                                        <span class="inline-flex w-full items-center justify-center rounded-2xl border border-slate-300 px-4 py-2 text-sm font-semibold uppercase tracking-wide text-slate-400">Conclua os modulos</span>
                                    <?php else: ?>
                                        <a href="assessment.php?course_id=<?php echo (int) $course['id']; ?>" class="inline-flex w-full items-center justify-center rounded-2xl bg-brand-red px-4 py-2 text-sm font-semibold text-white shadow-glow transition hover:bg-brand-redDark focus:outline-none focus:ring-4 focus:ring-brand-red/30">
                                            Acessar avaliacao
                                        </a>
                                    <?php endif; ?>
                                    <?php if ($course['approved']): ?>
                                        <a href="certificate.php?course_id=<?php echo (int) $course['id']; ?>" class="inline-flex w-full items-center justify-center rounded-2xl border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-700 hover:text-white sm:w-auto">
                                            Certificado
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>



