<?php
require_once __DIR__ . '/../includes/auth.php';

require_roles(['admin', 'gestor']);

$pageTitle = 'Usuarios';
$db = get_db();

// Filtros de busca
$search = trim($_GET['q'] ?? '');
$filterRole = $_GET['f_role'] ?? '';
$validRoles = ['admin', 'gestor', 'aluno'];
$hasSearch = $search !== '';
$hasRole = in_array($filterRole, $validRoles, true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $name = trim($_POST['name'] ?? '');
        $email = strtolower(trim($_POST['email'] ?? ''));
        $role = $_POST['role'] ?? '';
        $password = $_POST['password'] ?? '';

        if (has_role('gestor')) {
            $role = 'aluno';
        }

        if (!$name || !$email || !$role || !$password) {
            flash('Preencha todos os campos.', 'warning');
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash('Informe um email valido.', 'warning');
        } elseif (!in_array($role, ['admin', 'gestor', 'aluno'], true)) {
            flash('Tipo de usuario invalido.', 'warning');
        } else {
            try {
                $stmt = $db->prepare('INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)');
                $passwordHash = password_hash($password, PASSWORD_DEFAULT);
                $stmt->bind_param('ssss', $name, $email, $passwordHash, $role);
                $stmt->execute();
                flash('Usuario criado com sucesso!', 'success');
            } catch (mysqli_sql_exception $e) {
                if ($e->getCode() === 1062) {
                    flash('Nao foi possivel criar o usuario. Email ja cadastrado.', 'danger');
                } else {
                    flash('Erro ao criar usuario: ' . $e->getMessage(), 'danger');
                }
            }
        }
    }

    if ($action === 'delete') {
        $userId = (int) ($_POST['user_id'] ?? 0);
        if ($userId === current_user()['id']) {
            flash('Voce nao pode remover o proprio usuario.', 'warning');
        } else {
            $current = current_user();
            if (has_role('gestor')) {
                $stmtRole = $db->prepare('SELECT role FROM users WHERE id = ?');
                $stmtRole->bind_param('i', $userId);
                $stmtRole->execute();
                $roleRow = $stmtRole->get_result()->fetch_assoc();
                if (!$roleRow) {
                    flash('Usuario nao encontrado.', 'warning');
                    redirect('users.php');
                }
                $targetRole = $roleRow['role'] ?? '';
                if ($targetRole !== 'aluno') {
                    flash('Gestores podem remover apenas perfis de alunos.', 'warning');
                    redirect('users.php');
                }
            }

            $stmt = $db->prepare('DELETE FROM users WHERE id = ? LIMIT 1');
            $stmt->bind_param('i', $userId);
            $stmt->execute();
            flash('Usuario removido.', 'success');
        }
    }

    if ($action === 'reset_password') {
        $userId = (int) ($_POST['user_id'] ?? 0);

        if ($userId <= 0) {
            flash('Selecione um usuario valido para redefinir a senha.', 'warning');
        } else {
            $stmtTarget = $db->prepare('SELECT id, role FROM users WHERE id = ? LIMIT 1');
            $stmtTarget->bind_param('i', $userId);
            $stmtTarget->execute();
            $targetUser = $stmtTarget->get_result()->fetch_assoc();

            if (!$targetUser) {
                flash('Usuario nao encontrado.', 'warning');
            } elseif (has_role('gestor') && ($targetUser['role'] ?? '') !== 'aluno') {
                flash('Gestores podem redefinir senha apenas de alunos.', 'warning');
            } else {
                try {
                    $newPassword = strtoupper(bin2hex(random_bytes(4)));
                } catch (Throwable $exception) {
                    $fallbackPool = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
                    $shuffled = str_shuffle($fallbackPool);
                    $newPassword = substr($shuffled, 0, 8);
                }

                $passwordHash = password_hash($newPassword, PASSWORD_DEFAULT);
                $stmtReset = $db->prepare('UPDATE users SET password_hash = ? WHERE id = ?');
                $stmtReset->bind_param('si', $passwordHash, $userId);

                if ($stmtReset->execute()) {
                    flash('Senha redefinida com sucesso. Nova senha temporaria: ' . $newPassword, 'success');
                } else {
                    flash('Nao foi possivel redefinir a senha do usuario.', 'danger');
                }
            }
        }
    }

    if ($action === 'signature_update') {
        $currentSignature = get_signature_settings();
        $previousImagePath = $currentSignature['image_path'] ?? null;
        $name = trim($_POST['signature_name'] ?? '');
        $title = trim($_POST['signature_title'] ?? '');
        $removeImage = isset($_POST['remove_signature_image']);
        $updatedImagePath = $previousImagePath;
        $uploadedPath = null;

        $signatureFile = $_FILES['signature_image'] ?? null;
        if ($signatureFile && ($signatureFile['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            $upload = store_uploaded_signature($signatureFile);
            if (!$upload['success']) {
                flash($upload['message'], 'warning');
                redirect('users.php');
            }
            $uploadedPath = $upload['path'];
            $updatedImagePath = $uploadedPath;
        }

        if ($removeImage && $uploadedPath !== null) {
            delete_uploaded_file($uploadedPath);
            $uploadedPath = null;
            $updatedImagePath = null;
        } elseif ($removeImage) {
            $updatedImagePath = null;
        }

        if ($name === '') {
            if ($uploadedPath !== null) {
                delete_uploaded_file($uploadedPath);
            }
            flash('Informe o nome que sera exibido na assinatura.', 'warning');
            redirect('users.php');
        }

        $saved = save_signature_settings([
            'name' => $name,
            'title' => $title,
            'image_path' => $updatedImagePath,
        ]);

        if (!$saved) {
            if ($uploadedPath !== null) {
                delete_uploaded_file($uploadedPath);
            }
            flash('Nao foi possivel salvar as configuracoes de assinatura.', 'danger');
        } else {
            if ($removeImage && $previousImagePath) {
                delete_uploaded_file($previousImagePath);
            } elseif ($uploadedPath !== null && $previousImagePath && $previousImagePath !== $uploadedPath) {
                delete_uploaded_file($previousImagePath);
            }
            flash('Assinatura eletronica atualizada com sucesso.', 'success');
        }

        redirect('users.php');
    }

    redirect('users.php');
}

// Consulta usuarios com contagem de cursos
if (!$hasSearch && !$hasRole) {
    $sql = 'SELECT u.id, u.name, u.email, u.role, u.created_at, COUNT(e.course_id) AS course_count
            FROM users u
            LEFT JOIN enrollments e ON e.user_id = u.id
            GROUP BY u.id, u.name, u.email, u.role, u.created_at
            ORDER BY u.name';
    $result = $db->query($sql);
} elseif ($hasSearch && !$hasRole) {
    $sql = 'SELECT u.id, u.name, u.email, u.role, u.created_at, COUNT(e.course_id) AS course_count
            FROM users u
            LEFT JOIN enrollments e ON e.user_id = u.id
            WHERE (u.name LIKE ? OR u.email LIKE ?)
            GROUP BY u.id, u.name, u.email, u.role, u.created_at
            ORDER BY u.name';
    $stmt = $db->prepare($sql);
    $like = '%' . $search . '%';
    $stmt->bind_param('ss', $like, $like);
    $stmt->execute();
    $result = $stmt->get_result();
} elseif (!$hasSearch && $hasRole) {
    $sql = 'SELECT u.id, u.name, u.email, u.role, u.created_at, COUNT(e.course_id) AS course_count
            FROM users u
            LEFT JOIN enrollments e ON e.user_id = u.id
            WHERE u.role = ?
            GROUP BY u.id, u.name, u.email, u.role, u.created_at
            ORDER BY u.name';
    $stmt = $db->prepare($sql);
    $stmt->bind_param('s', $filterRole);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $sql = 'SELECT u.id, u.name, u.email, u.role, u.created_at, COUNT(e.course_id) AS course_count
            FROM users u
            LEFT JOIN enrollments e ON e.user_id = u.id
            WHERE (u.name LIKE ? OR u.email LIKE ?) AND u.role = ?
            GROUP BY u.id, u.name, u.email, u.role, u.created_at
            ORDER BY u.name';
    $stmt = $db->prepare($sql);
    $like = '%' . $search . '%';
    $stmt->bind_param('sss', $like, $like, $filterRole);
    $stmt->execute();
    $result = $stmt->get_result();
}

$users = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
$signatureSettings = get_signature_settings();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/navbar.php';
require_once __DIR__ . '/../includes/alerts.php';
?>
<div class="mx-auto max-w-7xl space-y-8 px-4 pb-12">
    <div class="rounded-3xl border border-slate-200 bg-white/90 p-8 shadow shadow-slate-900/10">
        <h1 class="text-2xl font-bold tracking-tight text-brand-gray">Controle de usuarios</h1>
        <p class="mt-2 text-sm text-slate-500">Cadastre novos perfis, defina permissoes e mantenha o acesso seguro da plataforma.</p>
    </div>

    <div class="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]">
        <div class="space-y-6">
            <div class="rounded-3xl border border-slate-200 bg-white p-6 shadow shadow-slate-900/10">
                <h2 class="text-lg font-semibold text-brand-gray">Novo usuario</h2>
                <p class="mt-1 text-sm text-slate-500">Defina o perfil de acesso e envie uma senha provisoria ao colaborador.</p>
                <form method="post" class="mt-6 space-y-4" novalidate>
                    <input type="hidden" name="action" value="create">
                    <div>
                        <label for="name" class="mb-1 block text-sm font-semibold text-slate-600">Nome completo</label>
                        <input type="text" id="name" name="name" required placeholder="Ex.: Ana Santos" class="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 shadow-sm focus:border-brand-red focus:outline-none focus:ring-4 focus:ring-brand-red/20">
                    </div>
                    <div>
                        <label for="email" class="mb-1 block text-sm font-semibold text-slate-600">Email</label>
                        <input type="email" id="email" name="email" required placeholder="usuario@escola.com" class="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 shadow-sm focus:border-brand-red focus:outline-none focus:ring-4 focus:ring-brand-red/20">
                    </div>
                    <div>
                        <label for="role" class="mb-1 block text-sm font-semibold text-slate-600">Perfil de acesso</label>
                        <select id="role" name="role" required class="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 shadow-sm focus:border-brand-red focus:outline-none focus:ring-4 focus:ring-brand-red/20">
                            <option value="">Selecione</option>
                            <option value="admin">Administrador</option>
                            <option value="gestor">Gestor</option>
                            <option value="aluno">Aluno</option>
                        </select>
                    </div>
                    <div>
                        <label for="password" class="mb-1 block text-sm font-semibold text-slate-600">Senha provisoria</label>
                        <input type="password" id="password" name="password" required placeholder="Crie uma senha segura" class="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 shadow-sm focus:border-brand-red focus:outline-none focus:ring-4 focus:ring-brand-red/20">
                        <p class="mt-1 text-xs text-slate-500">A senha pode ser alterada pelo usuario no primeiro acesso.</p>
                    </div>
                    <div class="pt-2">
                        <button type="submit" class="inline-flex w-full items-center justify-center rounded-2xl bg-brand-red px-5 py-3 text-sm font-semibold text-white shadow-glow transition hover:bg-brand-redDark focus:outline-none focus:ring-4 focus:ring-brand-red/30">
                            Cadastrar usuario
                        </button>
                    </div>
                </form>
            </div>
            <div class="rounded-3xl border border-slate-200 bg-white p-6 shadow shadow-slate-900/10">
                <h2 class="text-lg font-semibold text-brand-gray">Assinatura eletronica</h2>
                <p class="mt-1 text-sm text-slate-500">Configure o nome, cargo e a imagem que serao exibidos nos certificados emitidos.</p>
                <?php $signatureImageUrl = asset_url($signatureSettings['image_path'] ?? null); ?>
                <form method="post" enctype="multipart/form-data" class="mt-6 space-y-4" novalidate>
                    <input type="hidden" name="action" value="signature_update">
                    <div>
                        <label for="signature_name" class="mb-1 block text-sm font-semibold text-slate-600">Nome exibido</label>
                        <input type="text" id="signature_name" name="signature_name" required value="<?php echo htmlspecialchars($signatureSettings['name']); ?>" placeholder="Nome completo do responsavel" class="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 shadow-sm focus:border-brand-red focus:outline-none focus:ring-4 focus:ring-brand-red/20">
                    </div>
                    <div>
                        <label for="signature_title" class="mb-1 block text-sm font-semibold text-slate-600">Cargo ou departamento (opcional)</label>
                        <input type="text" id="signature_title" name="signature_title" value="<?php echo htmlspecialchars($signatureSettings['title']); ?>" placeholder="Ex.: Coordenacao pedagogica" class="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 shadow-sm focus:border-brand-red focus:outline-none focus:ring-4 focus:ring-brand-red/20">
                    </div>
                    <div class="space-y-3">
                        <label for="signature_image" class="block text-sm font-semibold text-slate-600">Imagem da assinatura (PNG ate 2 MB)</label>
                        <?php if ($signatureImageUrl): ?>
                            <div class="flex items-center justify-between rounded-2xl border border-slate-200 bg-slate-50 p-3">
                                <span class="text-xs font-semibold uppercase tracking-wide text-slate-500">Assinatura atual</span>
                                <img src="<?php echo htmlspecialchars($signatureImageUrl); ?>" alt="Assinatura atual" class="h-12 w-auto">
                            </div>
                        <?php endif; ?>
                        <input type="file" id="signature_image" name="signature_image" accept="image/png" class="block w-full rounded-2xl border border-dashed border-slate-300 bg-white px-4 py-3 text-sm text-slate-700 shadow-sm focus:border-brand-red focus:outline-none focus:ring-4 focus:ring-brand-red/20">
                        <p class="text-xs text-slate-500">Utilize uma imagem com fundo transparente para melhor resultado na impressao.</p>
                        <?php if (!empty($signatureSettings['image_path'])): ?>
                            <label class="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                                <input type="checkbox" name="remove_signature_image" value="1" class="h-4 w-4 rounded border-slate-300 text-brand-red focus:ring-brand-red/40">
                                <span>Remover imagem atual</span>
                            </label>
                        <?php endif; ?>
                    </div>
                    <div class="pt-2">
                        <button type="submit" class="inline-flex w-full items-center justify-center rounded-2xl bg-brand-gray px-5 py-3 text-sm font-semibold text-white transition hover:bg-brand-gray/90 focus:outline-none focus:ring-4 focus:ring-brand-red/20">
                            Salvar assinatura
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <div class="rounded-3xl border border-slate-200 bg-white shadow shadow-slate-900/10">
            <div class="flex flex-col gap-4 border-b border-slate-100 px-6 py-5 md:flex-row md:items-center md:justify-between">
                <div>
                    <h2 class="text-lg font-semibold text-brand-gray">Usuarios cadastrados</h2>
                    <p class="text-sm text-slate-500"><?php echo count($users); ?> usuario(s) com acesso ao sistema.</p>
                </div>
                <form method="get" action="users.php" class="grid w-full gap-3 sm:flex sm:flex-wrap sm:items-end sm:justify-end">
                    <div class="flex w-full flex-col sm:w-auto">
                        <label for="q" class="mb-1 text-xs font-semibold uppercase tracking-wider text-slate-500">Buscar</label>
                        <input type="text" id="q" name="q" value="<?php echo htmlspecialchars($search); ?>" placeholder="Nome ou email" class="rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 shadow-sm focus:border-brand-red focus:outline-none focus:ring-4 focus:ring-brand-red/20">
                    </div>
                    <div class="flex w-full flex-col sm:w-auto">
                        <label for="f_role" class="mb-1 text-xs font-semibold uppercase tracking-wider text-slate-500">Perfil</label>
                        <select id="f_role" name="f_role" class="rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 shadow-sm focus:border-brand-red focus:outline-none focus:ring-4 focus:ring-brand-red/20">
                            <option value="">Todos</option>
                            <option value="admin" <?php echo $filterRole==='admin'?'selected':''; ?>>Administrador</option>
                            <option value="gestor" <?php echo $filterRole==='gestor'?'selected':''; ?>>Gestor</option>
                            <option value="aluno" <?php echo $filterRole==='aluno'?'selected':''; ?>>Aluno</option>
                        </select>
                    </div>
                    <div class="flex w-full items-center gap-2 pt-2 sm:w-auto sm:pt-0">
                        <button type="submit" class="inline-flex w-full items-center justify-center rounded-2xl bg-brand-red px-4 py-2 text-xs font-semibold uppercase tracking-wide text-white shadow-glow transition hover:bg-brand-redDark sm:w-auto">Filtrar</button>
                        <?php if ($hasSearch || $hasRole): ?>
                            <a href="users.php" class="inline-flex w-full items-center justify-center rounded-2xl border border-slate-300 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-slate-600 transition hover:bg-slate-700 hover:text-white sm:w-auto">Limpar</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 text-sm sm:min-w-[720px]">
                    <thead class="bg-brand-gray text-left text-xs font-semibold uppercase tracking-[0.25em] text-white">
                        <tr>
                            <th class="px-6 py-3">Nome</th>
                            <th class="px-6 py-3">Email</th>
                            <th class="px-6 py-3">Perfil</th>
                            <th class="px-6 py-3">Cursos</th>
                            <th class="px-6 py-3">Criado em</th>
                            <th class="px-6 py-3 text-right">Acoes</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 bg-white">
                        <?php foreach ($users as $row): ?>
                            <tr class="transition hover:bg-slate-50">
                                <td class="px-6 py-4 font-semibold text-slate-700"><?php echo htmlspecialchars($row['name']); ?></td>
                                <td class="px-6 py-4 text-slate-500"><?php echo htmlspecialchars($row['email']); ?></td>
                                <td class="px-6 py-4">
                                    <span class="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-slate-100 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-slate-600"><?php echo htmlspecialchars($row['role']); ?></span>
                                </td>
                                <td class="px-6 py-4 text-slate-500"><?php echo (int) ($row['course_count'] ?? 0); ?></td>
                                <td class="px-6 py-4 text-slate-500"><?php echo $row['created_at'] ? date('d/m/Y', strtotime($row['created_at'])) : '-'; ?></td>
                                <td class="px-6 py-4 text-right">
                                    <div class="flex flex-wrap gap-2 sm:justify-end">
                                        <a href="user_detail.php?user_id=<?php echo (int) $row['id']; ?>" class="inline-flex w-full items-center justify-center rounded-full border border-slate-300 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-slate-600 transition hover:bg-slate-700 hover:text-white sm:w-auto">Editar</a>
                                        <form method="post" class="flex w-full sm:w-auto">
                                            <input type="hidden" name="action" value="reset_password">
                                            <input type="hidden" name="user_id" value="<?php echo (int) $row['id']; ?>">
                                            <button type="submit" data-confirm="Gerar uma nova senha temporaria para este usuario?" class="inline-flex w-full items-center justify-center rounded-full border border-amber-300 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-amber-700 transition hover:bg-amber-500 hover:text-white sm:w-auto">
                                                Redefinir senha
                                            </button>
                                        </form>
                                        <?php if ((int) $row['id'] !== current_user()['id']): ?>
                                            <form method="post" class="flex w-full sm:w-auto">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="user_id" value="<?php echo (int) $row['id']; ?>">
                                                <button type="submit" data-confirm="Remover este usuario?" class="inline-flex w-full items-center justify-center rounded-full border border-rose-300 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-rose-600 transition hover:bg-rose-500 hover:text-white sm:w-auto">
                                                    Remover
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <span class="text-xs uppercase tracking-wide text-slate-400">Voce</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($users)): ?>
                            <tr>
                                <td colspan="5" class="px-6 py-12 text-center text-sm text-slate-500">Nenhum usuario cadastrado ate o momento.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
