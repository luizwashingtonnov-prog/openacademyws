﻿<?php
require_once __DIR__ . '/../includes/auth.php';
require_login();

$user = current_user();
$currentPage = basename($_SERVER['PHP_SELF']);

function nav_active_class(string $page, string $current, array $extra = []): string
{
    $pages = array_merge([$page], $extra);
    return in_array($current, $pages, true) ? 'bg-white/20 text-white shadow' : 'text-white/80 hover:text-white hover:bg-white/10';
}
?>
<nav class="bg-gradient-to-r from-brand-red to-brand-redDark text-white shadow-lg">
    <div class="mx-auto flex w-full max-w-7xl flex-wrap items-center justify-between gap-4 px-4 py-4 sm:flex-nowrap sm:gap-6">
        <a class="text-lg font-bold uppercase tracking-wide" href="dashboard.php">Training</a>
        <div class="flex flex-1 flex-wrap items-center justify-between gap-3 sm:justify-end">
            <div class="flex flex-wrap items-center gap-2">
                <a class="rounded-full px-4 py-2 text-sm font-semibold transition <?php echo nav_active_class('dashboard.php', $currentPage); ?>" href="dashboard.php">Dashboard</a>
                <?php if (has_role('admin')): ?>
                    <a class="rounded-full px-4 py-2 text-sm font-semibold transition <?php echo nav_active_class('users.php', $currentPage, ['user_detail.php']); ?>" href="users.php">Usuarios</a>
                    <a class="rounded-full px-4 py-2 text-sm font-semibold transition <?php echo nav_active_class('admin_students.php', $currentPage); ?>" href="admin_students.php">Alunos</a>
                <?php endif; ?>
                <?php if (has_role('admin') || has_role('gestor')): ?>
                    <a class="rounded-full px-4 py-2 text-sm font-semibold transition <?php echo nav_active_class('courses.php', $currentPage, ['course_detail.php']); ?>" href="courses.php">Cursos</a>
                    <a class="rounded-full px-4 py-2 text-sm font-semibold transition <?php echo nav_active_class('questions.php', $currentPage); ?>" href="questions.php">Questoes</a>
                <?php endif; ?>
                <?php if (has_role('gestor')): ?>
                    <a class="rounded-full px-4 py-2 text-sm font-semibold transition <?php echo nav_active_class('manager_students.php', $currentPage); ?>" href="manager_students.php">Alunos</a>
                    <a class="rounded-full px-4 py-2 text-sm font-semibold transition <?php echo nav_active_class('users.php', $currentPage, ['user_detail.php']); ?>" href="users.php">Cadastrar usuarios</a>
                <?php endif; ?>
                <?php if (has_role('aluno')): ?>
                    <a class="rounded-full px-4 py-2 text-sm font-semibold transition <?php echo nav_active_class('my_courses.php', $currentPage); ?>" href="my_courses.php">Meus Cursos</a>
                    <a class="rounded-full px-4 py-2 text-sm font-semibold transition <?php echo nav_active_class('my_certificates.php', $currentPage); ?>" href="my_certificates.php">Meus Certificados</a>
                <?php endif; ?>
            </div>
            <div class="flex items-center gap-3 text-sm">
                <div class="text-right leading-tight">
                    <span class="block font-semibold">Olá, <?php echo htmlspecialchars($user['name']); ?></span>
                    <span class="text-white/70 uppercase text-xs tracking-wider"><?php echo htmlspecialchars($user['role']); ?></span>
                </div>
                <a class="inline-flex items-center justify-center rounded-full border border-white/30 px-4 py-2 text-xs font-semibold uppercase tracking-wider transition hover:bg-white hover:text-brand-red" href="logout.php">Sair</a>
            </div>
        </div>
    </div>
</nav>

